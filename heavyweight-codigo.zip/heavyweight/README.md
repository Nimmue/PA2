# HEAVYWEIGHT · Tienda en línea de productos deportivos

Proyecto web (avance 50 %) — tienda de zapatillas, ropa y accesorios **Nike, Adidas y Puma**.

## Tecnologías
| Capa | Tecnología |
|---|---|
| Estructura | HTML5 semántico |
| Estilos | CSS3 (variables, Grid, Flexbox, animaciones, responsive) |
| Interactividad | JavaScript ES6+ (módulos, async/await, fetch) |
| Framework | **Vue 3** (componentes, reactividad, transiciones) |
| Capa de servicio | **Node.js + Express** — API REST en capas |

## Cómo ejecutar
Requisito: Node.js 18 o superior.
```bash
npm install
npm start
```
Abrir **http://localhost:3000**  ·  API: **http://localhost:3000/api/products**

## Estructura
```
heavyweight/
├── backend/                  ← CAPA DE SERVICIO
│   ├── server.js             Arranque de Express, sirve API y frontend
│   ├── routes/               Mapea verbo + URL → controlador
│   ├── controllers/          Traduce HTTP ↔ servicio (sin lógica de negocio)
│   ├── services/             Reglas de negocio (filtros, stock, IGV, envío)
│   ├── repositories/         Acceso a datos (JSON / memoria)
│   ├── middlewares/          Logger, manejo de errores, 404
│   ├── utils/                AppError, formato de respuesta
│   └── data/                 products.json, brands.json
└── frontend/                 ← CLIENTE
    ├── index.html
    ├── css/styles.css
    └── js/
        ├── app.js            Componente raíz Vue
        ├── store.js          Estado global (carrito, notificaciones)
        ├── services/         Consumo de servicios: apiClient, productService, cartService, newsletterService
        ├── components/       AppHeader, HeroCarousel, BrandStrip, ProductCard, ProductModal, CartDrawer, NewsletterForm, ToastStack, ProductImage
        └── utils/format.js
```

## Flujo de datos
`Componente Vue → store → servicio cliente → apiClient (fetch) → /api → route → controller → service → repository → data`
y la respuesta vuelve con el formato estándar `{ ok, data, meta }` o `{ ok:false, error:{ message, status } }`.

## Endpoints
| Método | Ruta | Descripción |
|---|---|---|
| GET | `/api/health` | Estado del servicio |
| GET | `/api/products?brand=&category=&q=&maxPrice=&sort=` | Catálogo con filtros y orden |
| GET | `/api/products/:id` | Detalle (incluye descuento y disponibilidad) |
| GET | `/api/products/:id/related` | Productos relacionados |
| GET | `/api/brands` · `/api/categories` | Marcas y categorías con conteo |
| GET | `/api/cart/:cartId` | Ver carrito con subtotal, IGV, envío y total |
| POST | `/api/cart/:cartId/items` | Agregar `{ productId, size, quantity }` (valida talla y stock) |
| PATCH | `/api/cart/:cartId/items/:itemId` | Cambiar cantidad |
| DELETE | `/api/cart/:cartId/items/:itemId` | Quitar ítem |
| DELETE | `/api/cart/:cartId` | Vaciar carrito |
| POST | `/api/newsletter` | Suscripción `{ email }` |

## Avance
**Implementado (50 %):** página de inicio, carrusel, marcas, catálogo con búsqueda/filtros/orden, detalle de producto, carrito completo, newsletter, diseño responsive, API REST en capas.

**Pendiente (50 % restante):** registro e inicio de sesión, checkout y pasarela de pago, historial de pedidos, panel de administración, base de datos (MySQL/MongoDB).
