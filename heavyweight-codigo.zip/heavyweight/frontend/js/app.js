/**
 * HEAVYWEIGHT - Aplicación Vue 3 (componente raíz)
 * Orquesta los componentes y el catálogo con filtros.
 * Todo acceso a datos pasa por la capa de servicio del cliente (js/services).
 */
import AppHeader from './components/AppHeader.js';
import HeroCarousel from './components/HeroCarousel.js';
import BrandStrip from './components/BrandStrip.js';
import ProductCard from './components/ProductCard.js';
import ProductModal from './components/ProductModal.js';
import CartDrawer from './components/CartDrawer.js';
import NewsletterForm from './components/NewsletterForm.js';
import ToastStack from './components/ToastStack.js';
import { productService } from './services/productService.js';
import { store } from './store.js';
import { debounce, formatPrice } from './utils/format.js';

const { createApp } = Vue;

const App = {
  components: { AppHeader, HeroCarousel, BrandStrip, ProductCard, ProductModal, CartDrawer, NewsletterForm, ToastStack },
  data: () => ({
    store,
    products: [],
    offers: [],
    categories: [],
    loading: true,
    error: '',
    selectedId: null,
    filters: { q: '', brands: [], category: '', sort: '', maxPrice: 900 },
  }),
  computed: {
    activeFilterCount() {
      const f = this.filters;
      return f.brands.length + (f.category ? 1 : 0) + (f.q ? 1 : 0) + (f.maxPrice < 900 ? 1 : 0);
    },
  },
  watch: {
    'filters.q'() { this.debouncedLoad(); },
    'filters.brands': { deep: true, handler() { this.loadProducts(); } },
    'filters.category'() { this.loadProducts(); },
    'filters.sort'() { this.loadProducts(); },
    'filters.maxPrice'() { this.debouncedLoad(); },
  },
  created() {
    this.debouncedLoad = debounce(this.loadProducts, 350);
    this.loadProducts();
    this.loadOffers();
    productService.getCategories().then((c) => (this.categories = c)).catch(() => {});
    store.loadCart();
  },
  methods: {
    formatPrice,
    async loadProducts() {
      this.loading = true;
      this.error = '';
      try {
        const f = this.filters;
        this.products = await productService.getProducts({
          q: f.q, brand: f.brands.join(','), category: f.category, sort: f.sort, maxPrice: f.maxPrice < 900 ? f.maxPrice : '',
        });
      } catch (e) {
        this.error = e.message;
        this.products = [];
      } finally {
        this.loading = false;
      }
    },
    async loadOffers() {
      try {
        const all = await productService.getProducts({ sort: 'price-asc' });
        this.offers = all.filter((p) => p.discount > 0);
      } catch { /* el error ya se muestra en el catálogo */ }
    },
    toggleBrand(id) {
      const b = this.filters.brands;
      b.includes(id) ? b.splice(b.indexOf(id), 1) : b.push(id);
      this.scrollTo('catalogo');
    },
    resetFilters() {
      Object.assign(this.filters, { q: '', brands: [], category: '', sort: '', maxPrice: 900 });
    },
    open(product) { this.selectedId = product.id; },
    quickAdd(product) {
      if (product.sizes.length === 1) store.addToCart(product, product.sizes[0]);
      else { this.open(product); store.notify('Elige una talla para continuar', 'info'); }
    },
    onHeroCta(slide) {
      if (slide.category) this.filters.category = slide.category;
      this.scrollTo(slide.offers ? 'ofertas' : 'catalogo');
    },
    scrollTo(id) {
      const el = id === 'top' ? document.body : document.getElementById(id);
      el?.scrollIntoView({ behavior: 'smooth' });
    },
  },
  template: `
  <AppHeader v-model:search="filters.q" @go="scrollTo" />
  <main>
    <HeroCarousel @cta="onHeroCta" />

    <section class="perks container">
      <div><strong>🚚 Envío gratis</strong><span>en compras desde S/ 299</span></div>
      <div><strong>✅ 100 % original</strong><span>productos oficiales de marca</span></div>
      <div><strong>🔄 Cambios fáciles</strong><span>hasta 30 días</span></div>
    </section>

    <BrandStrip :active="filters.brands" @toggle="toggleBrand" />

    <section id="catalogo" class="section container">
      <div class="catalog-head">
        <h2 class="section-title">Catálogo</h2>
        <p class="muted">{{ loading ? 'Cargando...' : products.length + (products.length === 1 ? ' producto' : ' productos') }}</p>
      </div>

      <div class="filters">
        <div class="chips">
          <button :class="{ active: !filters.category }" @click="filters.category = ''">Todo</button>
          <button v-for="c in categories" :key="c.id" :class="{ active: filters.category === c.id }" @click="filters.category = c.id">
            {{ c.name }} <small>{{ c.productCount }}</small>
          </button>
        </div>
        <div class="filter-controls">
          <label class="range">Precio máx: <strong>{{ filters.maxPrice >= 900 ? 'Todos' : formatPrice(filters.maxPrice) }}</strong>
            <input type="range" min="50" max="900" step="25" v-model.number="filters.maxPrice" />
          </label>
          <select v-model="filters.sort" aria-label="Ordenar">
            <option value="">Destacados</option>
            <option value="price-asc">Precio: menor a mayor</option>
            <option value="price-desc">Precio: mayor a menor</option>
            <option value="rating">Mejor valorados</option>
            <option value="name">Nombre A-Z</option>
          </select>
          <button v-if="activeFilterCount" class="link" @click="resetFilters">Limpiar filtros ({{ activeFilterCount }})</button>
        </div>
      </div>

      <p v-if="error" class="error-box">⚠️ {{ error }} <button class="link" @click="loadProducts">Reintentar</button></p>

      <div v-if="loading" class="grid">
        <div v-for="n in 8" :key="n" class="card skeleton"><div class="sk-img"></div><div class="sk-line"></div><div class="sk-line short"></div></div>
      </div>
      <transition-group v-else-if="products.length" name="list" tag="div" class="grid">
        <ProductCard v-for="p in products" :key="p.id" :product="p" @open="open" @quick-add="quickAdd" />
      </transition-group>
      <div v-else-if="!error" class="empty">
        <p>No encontramos productos con esos filtros.</p>
        <button class="btn btn-primary" @click="resetFilters">Limpiar filtros</button>
      </div>
    </section>

    <section id="ofertas" class="section offers">
      <div class="container">
        <h2 class="section-title light">Ofertas de la semana</h2>
        <div class="offers-row">
          <ProductCard v-for="p in offers" :key="p.id" :product="p" @open="open" @quick-add="quickAdd" />
        </div>
      </div>
    </section>

    <NewsletterForm />
  </main>

  <footer class="footer">
    <div class="container footer-inner">
      <p class="logo">HEAVY<span>WEIGHT</span></p>
      <p class="muted">Tienda de productos deportivos · Mollendo, Arequipa · Proyecto académico (avance 50 %)</p>
      <p class="muted small">Nike, Adidas y Puma son marcas registradas de sus respectivos dueños.</p>
    </div>
  </footer>

  <ProductModal v-if="selectedId" :product-id="selectedId" @close="selectedId = null" @open="open" />
  <CartDrawer />
  <ToastStack />
  `,
};

createApp(App).mount('#app');
