/** Utilidades de formato. */
const money = new Intl.NumberFormat('es-PE', { style: 'currency', currency: 'PEN' });

export const formatPrice = (n) => money.format(n || 0);

export const brandName = (id) => ({ nike: 'Nike', adidas: 'Adidas', puma: 'Puma' }[id] || id);

/** Retrasa la ejecución hasta que el usuario deje de escribir. */
export function debounce(fn, ms = 350) {
  let t;
  return (...args) => {
    clearTimeout(t);
    t = setTimeout(() => fn(...args), ms);
  };
}
