/**
 * ESTADO GLOBAL (store reactivo de Vue)
 * Responsabilidad: guardar el carrito y las notificaciones compartidas
 * entre componentes, y orquestar las llamadas al cartService.
 */
import { cartService } from './services/cartService.js';

const { reactive } = Vue;

export const store = reactive({
  cart: { items: [], itemCount: 0, subtotal: 0, igv: 0, shipping: 0, total: 0, freeShippingFrom: 299 },
  cartOpen: false,
  cartBusy: false,
  toasts: [],

  notify(message, type = 'success') {
    const id = Date.now() + Math.random();
    this.toasts.push({ id, message, type });
    setTimeout(() => {
      this.toasts = this.toasts.filter((t) => t.id !== id);
    }, 3200);
  },

  async run(action, successMsg) {
    this.cartBusy = true;
    try {
      this.cart = await action();
      if (successMsg) this.notify(successMsg);
      return true;
    } catch (err) {
      this.notify(err.message, 'error');
      return false;
    } finally {
      this.cartBusy = false;
    }
  },

  loadCart() {
    return this.run(() => cartService.getCart());
  },
  addToCart(product, size, qty = 1) {
    return this.run(() => cartService.addItem(product.id, size, qty), `${product.name} (talla ${size}) agregado al carrito`);
  },
  changeQty(item, qty) {
    return this.run(() => cartService.updateQuantity(item.itemId, qty));
  },
  removeItem(item) {
    return this.run(() => cartService.removeItem(item.itemId), `${item.name} eliminado`);
  },
  clearCart() {
    return this.run(() => cartService.clear(), 'Carrito vaciado');
  },
});
