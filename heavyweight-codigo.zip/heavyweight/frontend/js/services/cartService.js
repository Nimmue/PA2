/**
 * CAPA DE SERVICIO (cliente) - Carrito
 * Responsabilidad: identificar al visitante con un cartId (guardado en
 * localStorage) y comunicarse con los endpoints /api/cart.
 */
import { apiClient } from './apiClient.js';

const STORAGE_KEY = 'hw-cart-id';

function getCartId() {
  let id = null;
  try { id = localStorage.getItem(STORAGE_KEY); } catch { /* modo privado */ }
  if (!id) {
    id = 'c-' + Math.random().toString(36).slice(2, 10) + Date.now().toString(36);
    try { localStorage.setItem(STORAGE_KEY, id); } catch { /* sin persistencia */ }
  }
  return id;
}

export const cartService = {
  getCart() {
    return apiClient.get(`/cart/${getCartId()}`);
  },
  addItem(productId, size, quantity = 1) {
    return apiClient.post(`/cart/${getCartId()}/items`, { productId, size, quantity });
  },
  updateQuantity(itemId, quantity) {
    return apiClient.patch(`/cart/${getCartId()}/items/${encodeURIComponent(itemId)}`, { quantity });
  },
  removeItem(itemId) {
    return apiClient.delete(`/cart/${getCartId()}/items/${encodeURIComponent(itemId)}`);
  },
  clear() {
    return apiClient.delete(`/cart/${getCartId()}`);
  },
};
