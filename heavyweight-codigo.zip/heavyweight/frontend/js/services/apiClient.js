/**
 * CAPA DE SERVICIO (cliente) - apiClient
 * Responsabilidad: única puerta de salida HTTP del frontend.
 *  - Arma la URL base.
 *  - Serializa JSON.
 *  - Normaliza errores: siempre lanza ApiError con mensaje legible.
 *  - Aplica timeout para no dejar la interfaz colgada.
 * Los demás servicios usan este cliente; los componentes NUNCA llaman fetch directo.
 */
const BASE_URL = '/api';
const TIMEOUT_MS = 8000;

export class ApiError extends Error {
  constructor(message, status = 0) {
    super(message);
    this.status = status;
  }
}

async function request(method, path, body) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);

  try {
    const res = await fetch(BASE_URL + path, {
      method,
      headers: body ? { 'Content-Type': 'application/json' } : undefined,
      body: body ? JSON.stringify(body) : undefined,
      signal: controller.signal,
    });
    const json = await res.json().catch(() => null);
    if (!res.ok || !json || json.ok === false) {
      throw new ApiError(json?.error?.message || `Error HTTP ${res.status}`, res.status);
    }
    return json.data;
  } catch (err) {
    if (err instanceof ApiError) throw err;
    if (err.name === 'AbortError') throw new ApiError('El servidor tardó demasiado en responder');
    throw new ApiError('No se pudo conectar con el servidor. ¿Ejecutaste "npm start"?');
  } finally {
    clearTimeout(timer);
  }
}

/** Convierte un objeto en query string ignorando valores vacíos. */
export function toQuery(params = {}) {
  const entries = Object.entries(params).filter(([, v]) => v !== undefined && v !== null && v !== '');
  return entries.length ? '?' + new URLSearchParams(entries).toString() : '';
}

export const apiClient = {
  get: (path) => request('GET', path),
  post: (path, body) => request('POST', path, body),
  patch: (path, body) => request('PATCH', path, body),
  delete: (path) => request('DELETE', path),
};
