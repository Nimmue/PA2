/**
 * CAPA DE SERVICIO (cliente) - Newsletter
 */
import { apiClient } from './apiClient.js';

export const newsletterService = {
  subscribe(email) {
    return apiClient.post('/newsletter', { email });
  },
};
