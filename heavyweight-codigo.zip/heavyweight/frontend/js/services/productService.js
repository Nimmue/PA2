/**
 * CAPA DE SERVICIO (cliente) - Productos
 * Responsabilidad: exponer operaciones del catálogo con nombres de negocio.
 * Incluye una caché simple para marcas y categorías (no cambian seguido).
 */
import { apiClient, toQuery } from './apiClient.js';

const cache = new Map();

async function cached(key, loader) {
  if (!cache.has(key)) cache.set(key, loader());
  try {
    return await cache.get(key);
  } catch (err) {
    cache.delete(key);
    throw err;
  }
}

export const productService = {
  /** filtros: { brand, category, q, minPrice, maxPrice, sort } */
  getProducts(filters = {}) {
    return apiClient.get('/products' + toQuery(filters));
  },
  getProduct(id) {
    return apiClient.get(`/products/${id}`);
  },
  getRelated(id) {
    return apiClient.get(`/products/${id}/related`);
  },
  getBrands() {
    return cached('brands', () => apiClient.get('/brands'));
  },
  getCategories() {
    return cached('categories', () => apiClient.get('/categories'));
  },
};
