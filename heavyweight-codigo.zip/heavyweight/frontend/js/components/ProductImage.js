/**
 * ProductImage: ilustración SVG generada según el tipo de producto y sus colores.
 * (Evita depender de imágenes externas con derechos de autor.)
 */
const SHAPES = {
  shoe: `
    <path d="M22 82 Q24 58 46 52 L78 44 Q94 30 112 39 L132 54 Q166 59 180 73 Q187 83 178 90 L32 92 Q19 90 22 82 Z" fill="var(--c1)"/>
    <path d="M18 90 L182 90 Q185 101 175 103 L27 103 Q15 101 18 90 Z" fill="var(--c2)"/>
    <path d="M60 70 Q100 60 150 76" stroke="var(--c2)" stroke-width="6" fill="none" stroke-linecap="round" opacity=".9"/>
    <g stroke="var(--c2)" stroke-width="3" stroke-linecap="round" opacity=".8">
      <line x1="88" y1="46" x2="98" y2="54"/><line x1="98" y1="42" x2="108" y2="50"/><line x1="108" y1="40" x2="117" y2="48"/>
    </g>`,
  shirt: `
    <path d="M68 18 L88 10 Q100 22 112 10 L132 18 L160 42 L143 58 L132 50 L132 108 L68 108 L68 50 L57 58 L40 42 Z" fill="var(--c1)"/>
    <path d="M88 10 Q100 22 112 10" stroke="var(--c2)" stroke-width="4" fill="none"/>
    <path d="M40 42 L57 58 L68 50 L68 46 Z M160 42 L143 58 L132 50 L132 46 Z" fill="var(--c2)" opacity=".6"/>
    <circle cx="116" cy="38" r="5" fill="var(--c2)"/>`,
  pants: `
    <path d="M70 10 L130 10 L138 110 L108 110 L100 45 L92 110 L62 110 Z" fill="var(--c1)"/>
    <rect x="70" y="10" width="60" height="9" fill="var(--c2)"/>
    <line x1="74" y1="22" x2="66" y2="106" stroke="var(--c2)" stroke-width="4"/>
    <line x1="126" y1="22" x2="134" y2="106" stroke="var(--c2)" stroke-width="4"/>`,
  bag: `
    <path d="M75 30 Q75 12 100 12 Q125 12 125 30" stroke="var(--c2)" stroke-width="6" fill="none"/>
    <rect x="58" y="28" width="84" height="84" rx="16" fill="var(--c1)"/>
    <rect x="72" y="62" width="56" height="36" rx="8" fill="var(--c2)" opacity=".35"/>
    <line x1="72" y1="62" x2="128" y2="62" stroke="var(--c2)" stroke-width="3"/>`,
  ball: `
    <circle cx="100" cy="60" r="50" fill="var(--c1)" stroke="#222" stroke-width="2"/>
    <polygon points="100,40 119,54 112,76 88,76 81,54" fill="#222"/>
    <g stroke="#222" stroke-width="3"><line x1="100" y1="40" x2="100" y2="12"/><line x1="119" y1="54" x2="146" y2="44"/>
    <line x1="112" y1="76" x2="128" y2="100"/><line x1="88" y1="76" x2="72" y2="100"/><line x1="81" y1="54" x2="54" y2="44"/></g>`,
  cap: `
    <path d="M50 78 Q50 26 100 26 Q150 26 150 78 Z" fill="var(--c1)"/>
    <path d="M40 78 L178 78 Q186 92 160 94 L44 90 Q32 86 40 78 Z" fill="var(--c2)"/>
    <circle cx="100" cy="27" r="5" fill="var(--c2)"/>
    <line x1="100" y1="30" x2="100" y2="78" stroke="var(--c2)" stroke-width="2" opacity=".5"/>`,
};

function shapeFor(product) {
  const n = product.name.toLowerCase();
  if (product.category === 'zapatillas') return 'shoe';
  if (n.includes('pantal')) return 'pants';
  if (product.category === 'ropa') return 'shirt';
  if (n.includes('mochila')) return 'bag';
  if (n.includes('pelota')) return 'ball';
  return 'cap';
}

export default {
  name: 'ProductImage',
  props: { product: { type: Object, required: true }, big: Boolean },
  computed: {
    svg() {
      return SHAPES[shapeFor(this.product)];
    },
    style() {
      const [c1, c2] = this.product.colors;
      return { '--c1': c1, '--c2': c2 || '#ffffff' };
    },
  },
  template: `
    <div class="product-art" :class="['art-' + product.brand, { big }]" :style="style">
      <svg viewBox="0 0 200 120" role="img" :aria-label="product.name" v-html="svg"></svg>
    </div>`,
};
