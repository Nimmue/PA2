/**
 * ProductModal: detalle del producto.
 * Consume GET /api/products/:id y GET /api/products/:id/related.
 */
import ProductImage from './ProductImage.js';
import { productService } from '../services/productService.js';
import { store } from '../store.js';
import { formatPrice, brandName } from '../utils/format.js';

export default {
  name: 'ProductModal',
  components: { ProductImage },
  props: { productId: Number },
  emits: ['close', 'open'],
  data: () => ({ product: null, related: [], size: '', qty: 1, loading: true, error: '', sizeError: false, store }),
  watch: {
    productId: { immediate: true, handler: 'load' },
  },
  mounted() {
    this.onKey = (e) => e.key === 'Escape' && this.$emit('close');
    window.addEventListener('keydown', this.onKey);
    document.body.style.overflow = 'hidden';
  },
  unmounted() {
    window.removeEventListener('keydown', this.onKey);
    document.body.style.overflow = '';
  },
  methods: {
    formatPrice, brandName,
    async load() {
      this.loading = true; this.error = ''; this.size = ''; this.qty = 1; this.sizeError = false;
      try {
        const [product, related] = await Promise.all([
          productService.getProduct(this.productId),
          productService.getRelated(this.productId),
        ]);
        this.product = product;
        this.related = related;
        if (product.sizes.length === 1) this.size = product.sizes[0];
      } catch (e) {
        this.error = e.message;
      } finally {
        this.loading = false;
      }
    },
    changeQty(delta) {
      this.qty = Math.min(Math.max(1, this.qty + delta), this.product.stock);
    },
    async add() {
      if (!this.size) { this.sizeError = true; return; }
      const ok = await store.addToCart(this.product, this.size, this.qty);
      if (ok) { this.$emit('close'); store.cartOpen = true; }
    },
  },
  template: `
  <div class="overlay" @click.self="$emit('close')">
    <div class="modal" role="dialog" aria-modal="true">
      <button class="close" @click="$emit('close')" aria-label="Cerrar">×</button>

      <div v-if="loading" class="modal-loading"><div class="spinner"></div></div>
      <p v-else-if="error" class="error-box">{{ error }}</p>

      <template v-else>
        <div class="modal-grid">
          <ProductImage :product="product" big />
          <div class="modal-info">
            <p class="card-brand">{{ brandName(product.brand) }} · {{ product.category }}</p>
            <h2>{{ product.name }}</h2>
            <p class="rating">★ {{ product.rating }} / 5</p>
            <p class="price big">
              {{ formatPrice(product.price) }}
              <s v-if="product.oldPrice">{{ formatPrice(product.oldPrice) }}</s>
              <span v-if="product.discount" class="tag tag-sale">-{{ product.discount }}%</span>
            </p>
            <p class="desc">{{ product.description }}</p>

            <p class="label">Talla <span v-if="sizeError" class="hint-error">— elige una talla</span></p>
            <div class="sizes" :class="{ shake: sizeError }">
              <button v-for="s in product.sizes" :key="s" :class="{ selected: size === s }"
                      @click="size = s; sizeError = false">{{ s }}</button>
            </div>

            <p class="label">Cantidad</p>
            <div class="qty-row">
              <div class="qty">
                <button @click="changeQty(-1)" :disabled="qty <= 1">−</button>
                <span>{{ qty }}</span>
                <button @click="changeQty(1)" :disabled="qty >= product.stock">+</button>
              </div>
              <span class="stock" :class="product.availability">
                {{ product.availability === 'ultimas-unidades' ? '¡Últimas ' + product.stock + ' unidades!' : product.stock + ' en stock' }}
              </span>
            </div>

            <button class="btn btn-primary full" :disabled="store.cartBusy" @click="add">
              {{ store.cartBusy ? 'Agregando...' : 'Agregar al carrito · ' + formatPrice(product.price * qty) }}
            </button>
          </div>
        </div>

        <div v-if="related.length" class="related">
          <h3>También te puede gustar</h3>
          <div class="related-grid">
            <button v-for="r in related" :key="r.id" class="related-item" @click="$emit('open', r)">
              <ProductImage :product="r" />
              <span>{{ r.name }}</span>
              <strong>{{ formatPrice(r.price) }}</strong>
            </button>
          </div>
        </div>
      </template>
    </div>
  </div>`,
};
