/**
 * HeroCarousel: banner principal con cambio automático de diapositiva,
 * controles manuales y pausa al pasar el mouse.
 */
const SLIDES = [
  { kicker: 'Nueva temporada', title: 'Entrena más pesado.', text: 'Las mejores zapatillas y ropa de Nike, Adidas y Puma en un solo lugar.', cta: 'Ver catálogo', brand: '', theme: 'dark' },
  { kicker: 'Running', title: 'Corre sin límites.', text: 'Amortiguación de alto rendimiento para tus kilómetros diarios.', cta: 'Ver zapatillas', brand: '', category: 'zapatillas', theme: 'orange' },
  { kicker: 'Hasta 15 % OFF', title: 'Ofertas de la semana.', text: 'Precios especiales en productos seleccionados. Envío gratis desde S/ 299.', cta: 'Ver ofertas', offers: true, theme: 'red' },
];

export default {
  name: 'HeroCarousel',
  emits: ['cta'],
  data: () => ({ slides: SLIDES, current: 0, timer: null }),
  mounted() { this.start(); },
  unmounted() { this.stop(); },
  methods: {
    start() { this.stop(); this.timer = setInterval(this.next, 5000); },
    stop() { clearInterval(this.timer); },
    next() { this.current = (this.current + 1) % this.slides.length; },
    prev() { this.current = (this.current - 1 + this.slides.length) % this.slides.length; },
    goTo(i) { this.current = i; this.start(); },
  },
  template: `
  <section class="hero" @mouseenter="stop" @mouseleave="start">
    <transition-group name="fade" tag="div" class="hero-track">
      <div v-for="(s, i) in slides" v-show="i === current" :key="i" class="hero-slide" :class="'theme-' + s.theme">
        <div class="container hero-content">
          <p class="kicker">{{ s.kicker }}</p>
          <h1>{{ s.title }}</h1>
          <p class="hero-text">{{ s.text }}</p>
          <button class="btn btn-light" @click="$emit('cta', s)">{{ s.cta }} →</button>
        </div>
        <div class="hero-word" aria-hidden="true">HEAVYWEIGHT</div>
      </div>
    </transition-group>
    <button class="hero-arrow left" @click="prev(); start()" aria-label="Anterior">‹</button>
    <button class="hero-arrow right" @click="next(); start()" aria-label="Siguiente">›</button>
    <div class="hero-dots">
      <button v-for="(s, i) in slides" :key="i" :class="{ active: i === current }" @click="goTo(i)" :aria-label="'Diapositiva ' + (i + 1)"></button>
    </div>
  </section>`,
};
