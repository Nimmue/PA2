import ProductImage from './ProductImage.js';
import { formatPrice, brandName } from '../utils/format.js';

export default {
  name: 'ProductCard',
  components: { ProductImage },
  props: { product: { type: Object, required: true } },
  emits: ['open', 'quick-add'],
  methods: { formatPrice, brandName },
  template: `
  <article class="card" tabindex="0" @click="$emit('open', product)" @keyup.enter="$emit('open', product)">
    <div class="card-media">
      <ProductImage :product="product" />
      <div class="tags">
        <span v-if="product.isNew" class="tag tag-new">Nuevo</span>
        <span v-if="product.discount" class="tag tag-sale">-{{ product.discount }}%</span>
        <span v-if="product.availability === 'ultimas-unidades'" class="tag tag-low">¡Últimas {{ product.stock }}!</span>
      </div>
      <button class="quick-add" @click.stop="$emit('quick-add', product)">+ Agregar</button>
    </div>
    <div class="card-body">
      <p class="card-brand">{{ brandName(product.brand) }} · {{ product.category }}</p>
      <h3 class="card-title">{{ product.name }}</h3>
      <div class="card-foot">
        <p class="price">
          {{ formatPrice(product.price) }}
          <s v-if="product.oldPrice">{{ formatPrice(product.oldPrice) }}</s>
        </p>
        <span class="rating" :title="product.rating + ' de 5'">★ {{ product.rating }}</span>
      </div>
    </div>
  </article>`,
};
