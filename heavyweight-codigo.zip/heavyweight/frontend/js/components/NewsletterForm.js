import { newsletterService } from '../services/newsletterService.js';

export default {
  name: 'NewsletterForm',
  data: () => ({ email: '', status: 'idle', message: '' }),
  computed: {
    valid() { return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(this.email.trim()); },
  },
  methods: {
    async submit() {
      if (!this.valid) { this.status = 'error'; this.message = 'Ingresa un correo válido.'; return; }
      this.status = 'loading';
      try {
        const res = await newsletterService.subscribe(this.email);
        this.status = 'success'; this.message = res.message; this.email = '';
      } catch (e) {
        this.status = 'error'; this.message = e.message;
      }
    },
  },
  template: `
  <section id="contacto" class="newsletter">
    <div class="container nl-inner">
      <div>
        <h2>Únete al club HEAVYWEIGHT</h2>
        <p>Recibe lanzamientos y ofertas exclusivas. 10 % de descuento en tu primera compra.</p>
      </div>
      <form class="nl-form" @submit.prevent="submit" novalidate>
        <input type="email" v-model="email" placeholder="tu@correo.com" :class="{ invalid: status === 'error' }" aria-label="Correo electrónico" />
        <button class="btn btn-primary" :disabled="status === 'loading'">{{ status === 'loading' ? 'Enviando...' : 'Suscribirme' }}</button>
        <p v-if="message" class="nl-msg" :class="status">{{ message }}</p>
      </form>
    </div>
  </section>`,
};
