import { productService } from '../services/productService.js';

export default {
  name: 'BrandStrip',
  props: { active: Array },
  emits: ['toggle'],
  data: () => ({ brands: [], error: '' }),
  async created() {
    try {
      this.brands = await productService.getBrands();
    } catch (e) {
      this.error = e.message;
    }
  },
  template: `
  <section id="marcas" class="section container">
    <h2 class="section-title">Nuestras marcas</h2>
    <p v-if="error" class="error-box">{{ error }}</p>
    <div class="brand-grid">
      <button v-for="b in brands" :key="b.id" class="brand-card" :class="['brand-' + b.id, { active: active.includes(b.id) }]"
              @click="$emit('toggle', b.id)">
        <span class="brand-name">{{ b.name }}</span>
        <span class="brand-slogan">{{ b.slogan }}</span>
        <span class="brand-count">{{ b.productCount }} productos</span>
      </button>
    </div>
  </section>`,
};
