/**
 * CartDrawer: panel lateral del carrito.
 * Consume GET/PATCH/DELETE /api/cart. Los totales (IGV, envío) los calcula
 * la capa de servicio del backend, no el cliente.
 */
import { store } from '../store.js';
import { formatPrice, brandName } from '../utils/format.js';

export default {
  name: 'CartDrawer',
  data: () => ({ store }),
  computed: {
    cart() { return store.cart; },
    shippingProgress() {
      return Math.min(100, Math.round((this.cart.total - this.cart.shipping) / this.cart.freeShippingFrom * 100));
    },
    missingForFree() {
      return Math.max(0, this.cart.freeShippingFrom - (this.cart.total - this.cart.shipping));
    },
  },
  methods: {
    formatPrice, brandName,
    checkout() {
      store.notify('El checkout y pago se implementarán en la Unidad 3 (50 % restante).', 'info');
    },
  },
  template: `
  <transition name="fade"><div v-if="store.cartOpen" class="overlay" @click="store.cartOpen = false"></div></transition>
  <transition name="slide">
    <aside v-if="store.cartOpen" class="drawer" aria-label="Carrito de compras">
      <div class="drawer-head">
        <h2>Tu carrito <small>({{ cart.itemCount }})</small></h2>
        <button class="close" @click="store.cartOpen = false" aria-label="Cerrar">×</button>
      </div>

      <div v-if="!cart.items.length" class="empty">
        <p>Tu carrito está vacío.</p>
        <button class="btn btn-primary" @click="store.cartOpen = false">Seguir comprando</button>
      </div>

      <template v-else>
        <div class="ship-bar">
          <p v-if="missingForFree > 0">Te faltan <strong>{{ formatPrice(missingForFree) }}</strong> para envío gratis</p>
          <p v-else>🎉 ¡Tienes envío gratis!</p>
          <div class="bar"><span :style="{ width: shippingProgress + '%' }"></span></div>
        </div>

        <ul class="cart-list" :class="{ busy: store.cartBusy }">
          <transition-group name="list">
            <li v-for="item in cart.items" :key="item.itemId" class="cart-item">
              <div class="ci-thumb" :class="'brand-' + item.brand">{{ brandName(item.brand)[0] }}</div>
              <div class="ci-info">
                <p class="ci-name">{{ item.name }}</p>
                <p class="ci-meta">{{ brandName(item.brand) }} · Talla {{ item.size }}</p>
                <div class="qty small">
                  <button @click="store.changeQty(item, item.quantity - 1)">−</button>
                  <span>{{ item.quantity }}</span>
                  <button @click="store.changeQty(item, item.quantity + 1)">+</button>
                </div>
              </div>
              <div class="ci-right">
                <strong>{{ formatPrice(item.lineTotal) }}</strong>
                <button class="link" @click="store.removeItem(item)">Quitar</button>
              </div>
            </li>
          </transition-group>
        </ul>

        <div class="totals">
          <p><span>Subtotal (sin IGV)</span><span>{{ formatPrice(cart.subtotal) }}</span></p>
          <p><span>IGV (18 %)</span><span>{{ formatPrice(cart.igv) }}</span></p>
          <p><span>Envío</span><span>{{ cart.shipping ? formatPrice(cart.shipping) : 'Gratis' }}</span></p>
          <p class="total"><span>Total</span><span>{{ formatPrice(cart.total) }}</span></p>
          <button class="btn btn-primary full" @click="checkout">Ir a pagar</button>
          <button class="link center" @click="store.clearCart()">Vaciar carrito</button>
        </div>
      </template>
    </aside>
  </transition>`,
};
