import { store } from '../store.js';

export default {
  name: 'AppHeader',
  props: { search: String },
  emits: ['update:search', 'go'],
  data: () => ({ store, scrolled: false, menuOpen: false }),
  mounted() {
    this.onScroll = () => (this.scrolled = window.scrollY > 20);
    window.addEventListener('scroll', this.onScroll);
  },
  unmounted() {
    window.removeEventListener('scroll', this.onScroll);
  },
  methods: {
    go(section) {
      this.menuOpen = false;
      this.$emit('go', section);
    },
  },
  template: `
  <header class="header" :class="{ scrolled }">
    <div class="container header-inner">
      <a href="#" class="logo" @click.prevent="go('top')">HEAVY<span>WEIGHT</span></a>

      <nav class="nav" :class="{ open: menuOpen }">
        <a href="#marcas" @click.prevent="go('marcas')">Marcas</a>
        <a href="#catalogo" @click.prevent="go('catalogo')">Catálogo</a>
        <a href="#ofertas" @click.prevent="go('ofertas')">Ofertas</a>
        <a href="#contacto" @click.prevent="go('contacto')">Contacto</a>
      </nav>

      <div class="header-actions">
        <label class="search">
          <span class="sr-only">Buscar productos</span>
          <svg viewBox="0 0 24 24" width="18" height="18"><circle cx="11" cy="11" r="7" fill="none" stroke="currentColor" stroke-width="2"/><line x1="16.5" y1="16.5" x2="21" y2="21" stroke="currentColor" stroke-width="2"/></svg>
          <input type="search" placeholder="Buscar zapatillas, polos..." :value="search"
                 @input="$emit('update:search', $event.target.value)" />
        </label>
        <button class="cart-btn" @click="store.cartOpen = true" aria-label="Abrir carrito">
          <svg viewBox="0 0 24 24" width="22" height="22"><path d="M3 4h2l2.4 11.2a2 2 0 0 0 2 1.6h7.7a2 2 0 0 0 2-1.5L21 8H6" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/><circle cx="10" cy="20" r="1.4" fill="currentColor"/><circle cx="17" cy="20" r="1.4" fill="currentColor"/></svg>
          <transition name="pop"><span v-if="store.cart.itemCount" :key="store.cart.itemCount" class="badge">{{ store.cart.itemCount }}</span></transition>
        </button>
        <button class="burger" @click="menuOpen = !menuOpen" aria-label="Menú"><span></span><span></span><span></span></button>
      </div>
    </div>
  </header>`,
};
