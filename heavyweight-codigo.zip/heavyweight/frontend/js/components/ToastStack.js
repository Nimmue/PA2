import { store } from '../store.js';

export default {
  name: 'ToastStack',
  data: () => ({ store }),
  template: `
  <div class="toasts" aria-live="polite">
    <transition-group name="toast">
      <div v-for="t in store.toasts" :key="t.id" class="toast" :class="t.type">{{ t.message }}</div>
    </transition-group>
  </div>`,
};
