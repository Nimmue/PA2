/**
 * Formato estándar de respuesta de la API:
 *   éxito -> { ok: true,  data, meta }
 *   error -> { ok: false, error: { message, status } }
 */
function ok(res, data, meta = {}) {
  res.json({ ok: true, data, meta });
}

function fail(res, status, message) {
  res.status(status).json({ ok: false, error: { message, status } });
}

module.exports = { ok, fail };
