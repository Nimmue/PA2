/**
 * Error de aplicación con código HTTP.
 * Lo lanzan los servicios y lo traduce el middleware de errores.
 */
class AppError extends Error {
  constructor(message, status = 400) {
    super(message);
    this.status = status;
  }
}

module.exports = AppError;
