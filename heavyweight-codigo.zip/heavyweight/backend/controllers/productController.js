/**
 * CONTROLADOR - Productos
 * Responsabilidad: traducir HTTP <-> servicio.
 * Lee parámetros de la petición, llama al servicio y responde JSON.
 * No contiene reglas de negocio.
 */
const productService = require('../services/productService');
const { ok } = require('../utils/response');

const productController = {
  list(req, res) {
    const data = productService.list(req.query);
    ok(res, data, { count: data.length });
  },
  getById(req, res) {
    ok(res, productService.getById(req.params.id));
  },
  getRelated(req, res) {
    ok(res, productService.getRelated(req.params.id));
  },
  brands(req, res) {
    ok(res, productService.getBrands());
  },
  categories(req, res) {
    ok(res, productService.getCategories());
  },
};

module.exports = productController;
