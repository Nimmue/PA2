/**
 * CONTROLADOR - Newsletter
 */
const newsletterService = require('../services/newsletterService');
const { ok } = require('../utils/response');

module.exports = {
  subscribe(req, res) {
    res.status(201);
    ok(res, newsletterService.subscribe(req.body.email));
  },
};
