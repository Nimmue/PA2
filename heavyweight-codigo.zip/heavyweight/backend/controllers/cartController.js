/**
 * CONTROLADOR - Carrito
 */
const cartService = require('../services/cartService');
const { ok } = require('../utils/response');

const cartController = {
  get(req, res) {
    ok(res, cartService.getCart(req.params.cartId));
  },
  addItem(req, res) {
    res.status(201);
    ok(res, cartService.addItem(req.params.cartId, req.body));
  },
  updateItem(req, res) {
    ok(res, cartService.updateQuantity(req.params.cartId, req.params.itemId, req.body.quantity));
  },
  removeItem(req, res) {
    ok(res, cartService.removeItem(req.params.cartId, req.params.itemId));
  },
  clear(req, res) {
    ok(res, cartService.clear(req.params.cartId));
  },
};

module.exports = cartController;
