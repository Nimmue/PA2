/**
 * HEAVYWEIGHT - Servidor principal
 * Levanta la API REST (/api) y sirve el frontend estático.
 *
 * Arquitectura (capas):
 *   Cliente (Vue)  ->  routes  ->  controllers  ->  services  ->  repositories  ->  data
 */
const path = require('path');
const express = require('express');
const cors = require('cors');
const apiRoutes = require('./routes');
const { logger, notFound, errorHandler } = require('./middlewares');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());
app.use(logger);

// API REST
app.use('/api', apiRoutes);
app.use('/api', notFound);

// Framework Vue 3 servido desde node_modules (funciona sin internet)
app.use('/vendor', express.static(path.join(__dirname, '..', 'node_modules', 'vue', 'dist')));

// Frontend
app.use(express.static(path.join(__dirname, '..', 'frontend')));

app.use(errorHandler);

app.listen(PORT, () => {
  console.log('==============================================');
  console.log('  HEAVYWEIGHT  ·  Tienda deportiva');
  console.log(`  Web:  http://localhost:${PORT}`);
  console.log(`  API:  http://localhost:${PORT}/api/products`);
  console.log('==============================================');
});
