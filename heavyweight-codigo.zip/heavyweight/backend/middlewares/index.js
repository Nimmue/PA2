/**
 * MIDDLEWARES transversales
 *  - logger: registra método, ruta, estado y tiempo de respuesta.
 *  - asyncHandler: captura errores de los controladores.
 *  - notFound / errorHandler: respuestas de error uniformes.
 */
const { fail } = require('../utils/response');

function logger(req, res, next) {
  const start = Date.now();
  res.on('finish', () => {
    if (req.originalUrl.startsWith('/api')) {
      console.log(`${req.method.padEnd(6)} ${req.originalUrl} -> ${res.statusCode} (${Date.now() - start} ms)`);
    }
  });
  next();
}

const asyncHandler = (fn) => (req, res, next) => {
  try {
    Promise.resolve(fn(req, res, next)).catch(next);
  } catch (err) {
    next(err);
  }
};

function notFound(req, res) {
  fail(res, 404, `Ruta no encontrada: ${req.method} ${req.originalUrl}`);
}

// eslint-disable-next-line no-unused-vars
function errorHandler(err, req, res, next) {
  const status = err.status || 500;
  if (status === 500) console.error(err);
  fail(res, status, status === 500 ? 'Error interno del servidor' : err.message);
}

module.exports = { logger, asyncHandler, notFound, errorHandler };
