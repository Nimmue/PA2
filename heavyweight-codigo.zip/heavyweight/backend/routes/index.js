/**
 * RUTAS de la API REST  (prefijo /api)
 * Responsabilidad: mapear verbo + URL -> controlador.
 */
const { Router } = require('express');
const { asyncHandler: h } = require('../middlewares');
const product = require('../controllers/productController');
const cart = require('../controllers/cartController');
const newsletter = require('../controllers/newsletterController');

const router = Router();

// Estado del servicio
router.get('/health', (req, res) => res.json({ ok: true, data: { status: 'up', time: new Date().toISOString() } }));

// Catálogo
router.get('/products', h(product.list));
router.get('/products/:id', h(product.getById));
router.get('/products/:id/related', h(product.getRelated));
router.get('/brands', h(product.brands));
router.get('/categories', h(product.categories));

// Carrito
router.get('/cart/:cartId', h(cart.get));
router.post('/cart/:cartId/items', h(cart.addItem));
router.patch('/cart/:cartId/items/:itemId', h(cart.updateItem));
router.delete('/cart/:cartId/items/:itemId', h(cart.removeItem));
router.delete('/cart/:cartId', h(cart.clear));

// Newsletter
router.post('/newsletter', h(newsletter.subscribe));

module.exports = router;
