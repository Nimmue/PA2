/**
 * CAPA DE ACCESO A DATOS (Repository)
 * Responsabilidad: leer los datos crudos. No contiene reglas de negocio.
 * Hoy lee archivos JSON; mañana podría ser MySQL o MongoDB sin tocar
 * los servicios ni los controladores.
 */
const products = require('../data/products.json');
const brands = require('../data/brands.json');

const productRepository = {
  findAll() {
    return products.map((p) => ({ ...p }));
  },

  findById(id) {
    const product = products.find((p) => p.id === id);
    return product ? { ...product } : null;
  },

  findAllBrands() {
    return brands.map((b) => ({ ...b }));
  },

  /** Descuenta stock (se usará en el checkout - Unidad 3). */
  updateStock(id, newStock) {
    const product = products.find((p) => p.id === id);
    if (product) product.stock = newStock;
    return product;
  },
};

module.exports = productRepository;
