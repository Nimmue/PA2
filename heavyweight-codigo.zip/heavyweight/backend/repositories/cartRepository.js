/**
 * CAPA DE ACCESO A DATOS (Repository) - Carritos
 * Almacenamiento en memoria: Map<cartId, { items: [] }>.
 */
const carts = new Map();

const cartRepository = {
  get(cartId) {
    if (!carts.has(cartId)) carts.set(cartId, { id: cartId, items: [], updatedAt: new Date().toISOString() });
    return carts.get(cartId);
  },

  save(cart) {
    cart.updatedAt = new Date().toISOString();
    carts.set(cart.id, cart);
    return cart;
  },

  clear(cartId) {
    carts.delete(cartId);
  },
};

module.exports = cartRepository;
