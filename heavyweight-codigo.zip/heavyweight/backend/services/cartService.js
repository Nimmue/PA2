/**
 * CAPA DE SERVICIO - Carrito de compras
 * Responsabilidad: reglas de negocio del carrito.
 *  - Validar stock y talla antes de agregar.
 *  - Unificar ítems repetidos (mismo producto + talla).
 *  - Calcular subtotal, IGV (18 %), envío y total.
 */
const cartRepository = require('../repositories/cartRepository');
const productRepository = require('../repositories/productRepository');
const AppError = require('../utils/AppError');

const IGV_RATE = 0.18;
const FREE_SHIPPING_FROM = 299;
const SHIPPING_COST = 15;
const round2 = (n) => Math.round(n * 100) / 100;

/** Construye la respuesta con totales calculados. */
function buildSummary(cart) {
  const items = cart.items.map((item) => {
    const product = productRepository.findById(item.productId);
    return {
      ...item,
      name: product.name,
      brand: product.brand,
      price: product.price,
      lineTotal: round2(product.price * item.quantity),
    };
  });

  const total = round2(items.reduce((sum, i) => sum + i.lineTotal, 0));
  // Los precios ya incluyen IGV: se desglosa la base imponible.
  const subtotal = round2(total / (1 + IGV_RATE));
  const igv = round2(total - subtotal);
  const shipping = total === 0 || total >= FREE_SHIPPING_FROM ? 0 : SHIPPING_COST;

  return {
    id: cart.id,
    items,
    itemCount: items.reduce((n, i) => n + i.quantity, 0),
    subtotal,
    igv,
    shipping,
    total: round2(total + shipping),
    freeShippingFrom: FREE_SHIPPING_FROM,
    updatedAt: cart.updatedAt,
  };
}

const cartService = {
  getCart(cartId) {
    return buildSummary(cartRepository.get(cartId));
  },

  addItem(cartId, { productId, quantity = 1, size }) {
    const product = productRepository.findById(Number(productId));
    if (!product) throw new AppError('El producto no existe', 404);
    if (!size || !product.sizes.includes(String(size))) {
      throw new AppError(`Talla no válida. Opciones: ${product.sizes.join(', ')}`, 400);
    }
    const qty = Number(quantity);
    if (!Number.isInteger(qty) || qty < 1) throw new AppError('La cantidad debe ser un entero mayor a 0', 400);

    const cart = cartRepository.get(cartId);
    const existing = cart.items.find((i) => i.productId === product.id && i.size === String(size));
    const newQty = (existing ? existing.quantity : 0) + qty;
    if (newQty > product.stock) throw new AppError(`Solo hay ${product.stock} unidades disponibles`, 409);

    if (existing) existing.quantity = newQty;
    else cart.items.push({ itemId: `${product.id}-${size}`, productId: product.id, size: String(size), quantity: qty });

    return buildSummary(cartRepository.save(cart));
  },

  updateQuantity(cartId, itemId, quantity) {
    const cart = cartRepository.get(cartId);
    const item = cart.items.find((i) => i.itemId === itemId);
    if (!item) throw new AppError('El ítem no está en el carrito', 404);

    const qty = Number(quantity);
    if (!Number.isInteger(qty) || qty < 0) throw new AppError('Cantidad no válida', 400);
    if (qty === 0) return this.removeItem(cartId, itemId);

    const product = productRepository.findById(item.productId);
    if (qty > product.stock) throw new AppError(`Solo hay ${product.stock} unidades disponibles`, 409);

    item.quantity = qty;
    return buildSummary(cartRepository.save(cart));
  },

  removeItem(cartId, itemId) {
    const cart = cartRepository.get(cartId);
    const before = cart.items.length;
    cart.items = cart.items.filter((i) => i.itemId !== itemId);
    if (cart.items.length === before) throw new AppError('El ítem no está en el carrito', 404);
    return buildSummary(cartRepository.save(cart));
  },

  clear(cartId) {
    cartRepository.clear(cartId);
    return buildSummary(cartRepository.get(cartId));
  },
};

module.exports = cartService;
