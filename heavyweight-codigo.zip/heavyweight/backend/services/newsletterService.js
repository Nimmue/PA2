/**
 * CAPA DE SERVICIO - Newsletter
 * Responsabilidad: validar y registrar suscripciones (sin duplicados).
 */
const AppError = require('../utils/AppError');

const subscribers = new Set();
const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

const newsletterService = {
  subscribe(email) {
    const clean = String(email || '').trim().toLowerCase();
    if (!EMAIL_REGEX.test(clean)) throw new AppError('Correo electrónico no válido', 400);
    if (subscribers.has(clean)) throw new AppError('Este correo ya está suscrito', 409);
    subscribers.add(clean);
    return { email: clean, coupon: 'HEAVY10', message: '¡Gracias! Usa el cupón HEAVY10 en tu primera compra.' };
  },
  count() {
    return subscribers.size;
  },
};

module.exports = newsletterService;
