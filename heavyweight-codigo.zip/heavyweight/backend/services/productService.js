/**
 * CAPA DE SERVICIO - Productos
 * Responsabilidad: reglas de negocio del catálogo.
 *  - Filtrar por marca, categoría, rango de precio y texto.
 *  - Ordenar resultados.
 *  - Calcular campos derivados (descuento %, disponibilidad).
 */
const productRepository = require('../repositories/productRepository');
const AppError = require('../utils/AppError');

const CATEGORIES = [
  { id: 'zapatillas', name: 'Zapatillas' },
  { id: 'ropa', name: 'Ropa' },
  { id: 'accesorios', name: 'Accesorios' },
];

const SORTERS = {
  'price-asc': (a, b) => a.price - b.price,
  'price-desc': (a, b) => b.price - a.price,
  rating: (a, b) => b.rating - a.rating,
  name: (a, b) => a.name.localeCompare(b.name),
};

/** Agrega campos calculados que la vista necesita. */
function enrich(product) {
  const discount = product.oldPrice
    ? Math.round((1 - product.price / product.oldPrice) * 100)
    : 0;
  let availability = 'disponible';
  if (product.stock === 0) availability = 'agotado';
  else if (product.stock <= 5) availability = 'ultimas-unidades';
  return { ...product, discount, availability };
}

const productService = {
  list({ brand, category, q, minPrice, maxPrice, sort } = {}) {
    let result = productRepository.findAll();

    if (brand) {
      const brandsWanted = String(brand).toLowerCase().split(',');
      result = result.filter((p) => brandsWanted.includes(p.brand));
    }
    if (category) result = result.filter((p) => p.category === category);
    if (q) {
      const text = String(q).trim().toLowerCase();
      result = result.filter(
        (p) => p.name.toLowerCase().includes(text) || p.description.toLowerCase().includes(text)
      );
    }
    if (minPrice !== undefined && minPrice !== '') result = result.filter((p) => p.price >= Number(minPrice));
    if (maxPrice !== undefined && maxPrice !== '') result = result.filter((p) => p.price <= Number(maxPrice));

    if (sort) {
      if (!SORTERS[sort]) throw new AppError(`Orden no válido: ${sort}`, 400);
      result.sort(SORTERS[sort]);
    }

    return result.map(enrich);
  },

  getById(id) {
    const numericId = Number(id);
    if (!Number.isInteger(numericId)) throw new AppError('El id debe ser numérico', 400);
    const product = productRepository.findById(numericId);
    if (!product) throw new AppError(`Producto ${id} no encontrado`, 404);
    return enrich(product);
  },

  getRelated(id, limit = 4) {
    const base = this.getById(id);
    return productRepository
      .findAll()
      .filter((p) => p.id !== base.id && (p.brand === base.brand || p.category === base.category))
      .slice(0, limit)
      .map(enrich);
  },

  getBrands() {
    const all = productRepository.findAll();
    return productRepository.findAllBrands().map((b) => ({
      ...b,
      productCount: all.filter((p) => p.brand === b.id).length,
    }));
  },

  getCategories() {
    const all = productRepository.findAll();
    return CATEGORIES.map((c) => ({ ...c, productCount: all.filter((p) => p.category === c.id).length }));
  },
};

module.exports = productService;
